package com.towerdefense.towerdefense.entities;
public interface CanAttack {

	public abstract void attack();

}
