package com.towerdefense.towerdefense.entities.mobs;

public class ForkBomb extends Mob {

}
