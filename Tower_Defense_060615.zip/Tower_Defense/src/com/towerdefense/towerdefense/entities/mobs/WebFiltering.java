package com.towerdefense.towerdefense.entities.mobs;

public class WebFiltering extends Mob {

}
