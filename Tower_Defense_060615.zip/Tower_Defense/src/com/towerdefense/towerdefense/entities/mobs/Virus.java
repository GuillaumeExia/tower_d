package com.towerdefense.towerdefense.entities.mobs;

public class Virus extends Mob {

}
