package com.towerdefense.towerdefense.entities.mobs;

public class Bug extends Mob {

}
