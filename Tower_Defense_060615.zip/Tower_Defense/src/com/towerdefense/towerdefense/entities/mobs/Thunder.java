package com.towerdefense.towerdefense.entities.mobs;

public class Thunder extends Mob {

}
