package com.towerdefense.towerdefense.entities;
public enum EntityType {

	Electric, Viral, Error, Hack, Heat;

}
