package com.towerdefense.towerdefense.entities;
public interface CanDie {

	public abstract void die();

}
