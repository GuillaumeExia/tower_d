package com.towerdefense.towerdefense.entities;
public interface CanMove {

	public abstract void move();

}
