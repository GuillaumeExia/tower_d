package com.towerdefense.towerdefense.entities.towers;

public class VPNTower extends Tower {

}
