package com.towerdefense.towerdefense.entities.towers;

public class TowerFactory {

	public Tower createTower() {
		return null;
	}
}
