package com.towerdefense.towerdefense.entities.towers;

public class WaterCoolerTower extends Tower {

}
