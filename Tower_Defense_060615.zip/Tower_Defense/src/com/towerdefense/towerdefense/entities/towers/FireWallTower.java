package com.towerdefense.towerdefense.entities.towers;

public class FireWallTower extends Tower {

}
