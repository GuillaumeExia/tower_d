package com.towerdefense.towerdefense.entities;
public interface CanDieAttack extends CanDie, CanAttack {

}
