package com.towerdefense.towerdefense.entities;
public interface CanBeRepaired {

	public abstract void repair();

}
