package com.towerdefense.towerdefense.entities;
public interface CanDieMoveAttack extends CanDie, CanAttack, CanMove {

}
