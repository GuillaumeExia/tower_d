package com.towerdefense.towerdefense.entities;

public class Entity {

}
