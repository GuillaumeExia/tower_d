package com.towerdefense.main;

import com.towerdefense.display.Window;
import com.towerdefense.towerdefense.GlobalVariables;

public class TowerDefense {

	public static void main(String[] args) {
		Window window = new Window();
		//Map map = new Map();
	}

}
